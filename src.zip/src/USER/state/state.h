#ifndef __STATE_H
#define __STATE_H

#include "sys.h"

extern u16 speed1;
extern u16 speed2;
extern unsigned char usart_msg[100];

#endif