#include "state.h"

u16 speed1;
u16 speed2;
unsigned char usart_msg[100];